// ln_worker.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>

void ln_worker_process(const char *filename, pid_t parent_pid) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        perror("Worker: Failed to open file");
        exit(1);
    }

    char buffer[4096];
    ssize_t bytes_read;
    int total = 0;

    size_t alloc_size = 60 * 1024 * 1024; // 60 MB
    char *mem_block = malloc(alloc_size);
    if (!mem_block) {
        perror("Memory allocation failed");
        close(fd);
        exit(1);
    }

    while ((bytes_read = read(fd, buffer, sizeof(buffer))) > 0) {
        memcpy(mem_block + total, buffer, bytes_read);
        total += bytes_read;

        FILE *status_file = fopen("/proc/self/status", "r");
        if (!status_file) {
            perror("Failed to open /proc/self/status");
            exit(1);
        }

        char line[256];
        int mem_usage = 0;
        while (fgets(line, sizeof(line), status_file)) {
            if (strncmp(line, "VmRSS:", 6) == 0) {
                sscanf(line + 6, "%d", &mem_usage);
                break;
            }
        }
        fclose(status_file);

        if (mem_usage > 50000) {
            kill(parent_pid, SIGUSR1);
        }
    }

    free(mem_block);
    close(fd);
    kill(parent_pid, SIGUSR2);
    exit(0);
}

// ADD THIS main FUNCTION FOR EXECUTION
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <binary_file>\n", argv[0]);
        return 1;
    }

    pid_t parent = getppid();
    ln_worker_process(argv[1], parent);
    return 0;
}
