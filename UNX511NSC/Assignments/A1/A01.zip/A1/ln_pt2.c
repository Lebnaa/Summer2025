// ln_pt2.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>

void ln_worker_process(const char *filename, pid_t parent_pid) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        perror("Worker: Failed to open file");
        exit(1);
    }

    const int chunk_size = 4096; // 4KB
    char *buffer = malloc(chunk_size);
    if (!buffer) {
        perror("Initial buffer alloc failed");
        exit(1);
    }

    size_t capacity = 128 * chunk_size; // Initial capacity fo data
    char *data_storage = malloc(capacity);
    size_t data_size = 0;
    int sigusr1_sent = 0;

    if (!data_storage) {
        perror("Memory allocation failed");
        free(buffer);
        close(fd);
        exit(1);
    }

    ssize_t bytes_read;
    while ((bytes_read = read(fd, buffer, chunk_size)) > 0) {
        // Grow storage buffer if needed
        if (data_size + bytes_read > capacity) {
            capacity *= 2;
            data_storage = realloc(data_storage, capacity);
            if (!data_storage) {
                perror("Realloc failed");
                free(buffer);
                close(fd);
                exit(1);
            }
        }

        // Store the read data
        memcpy(data_storage + data_size, buffer, bytes_read);
        data_size += bytes_read;

        // Check memory usage only if SIGUSR1 isn't sent yet
        if (!sigusr1_sent) {
            FILE *status_file = fopen("/proc/self/status", "r");
            if (!status_file) {
                perror("Failed to open /proc/self/status");
                free(buffer);
                free(data_storage);
                close(fd);
                exit(1);
            }

            char line[256];
            int mem_usage = 0;
            while (fgets(line, sizeof(line), status_file)) {
                if (strncmp(line, "VmRSS:", 6) == 0) {
                    sscanf(line + 6, "%d", &mem_usage); // in KB
                    break;
                }
            }
            fclose(status_file);

            if (mem_usage > 50000) { // 50MB
                kill(parent_pid, SIGUSR1);
                sigusr1_sent = 1;
            }
        }
    }

    free(buffer);
    free(data_storage);
    close(fd);

    // Notify parent of completion
    kill(parent_pid, SIGUSR2);
    exit(0);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <binary_file>\n", argv[0]);
        return 1;
    }

    pid_t parent_pid = getppid();
    ln_worker_process(argv[1], parent_pid);
    return 0;
}
