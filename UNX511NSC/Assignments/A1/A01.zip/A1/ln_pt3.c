// ln_pt3.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <time.h>

#define MAX_WORKERS 3

volatile sig_atomic_t completed_workers = 0;
pid_t worker_pids[MAX_WORKERS];
int logged_worker[MAX_WORKERS] = {0};  // 0 = not logged yet

// Secure logging with fcntl
void ln_log_event(const char *message) {
    int fd = open("syslog.log", O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd < 0) {
        perror("Log file open failed");
        return;
    }

    struct flock lock = {0};
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;
    lock.l_pid = getpid();

    if (fcntl(fd, F_SETLK, &lock) == -1) {
        perror("File lock failed");
        close(fd);
        return;
    }

    write(fd, message, strlen(message));

    lock.l_type = F_UNLCK;
    fcntl(fd, F_SETLK, &lock);
    close(fd);
}

int get_worker_index(pid_t pid) {
    for (int i = 0; i < MAX_WORKERS; i++) {
        if (worker_pids[i] == pid)
            return i;
    }
    return -1;
}

void ln_signal_handler(int sig, siginfo_t *info, void *context) {
    pid_t sender_pid = info->si_pid;
    int worker_index = get_worker_index(sender_pid);
    if (worker_index == -1) return;
    if (logged_worker[worker_index]) return;  // Already logged

    char buffer[256];

    if (sig == SIGUSR1) {
        snprintf(buffer, sizeof(buffer), "⚠️ Worker %d exceeded memory limit!\n", worker_index + 1);
    } else if (sig == SIGUSR2) {
        snprintf(buffer, sizeof(buffer), "✅ Worker %d completed.\n", worker_index + 1);
    } else {
        return;
    }

    printf("%s", buffer);
    ln_log_event(buffer);

    logged_worker[worker_index] = 1;
    completed_workers++;
}

void ln_setup_signals() {
    struct sigaction sa;
    sa.sa_sigaction = ln_signal_handler;
    sa.sa_flags = SA_SIGINFO;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGUSR1, &sa, NULL);
    sigaction(SIGUSR2, &sa, NULL);
}

int main() {
    ln_setup_signals();

    char *files[] = {"worker1.bin", "worker2.bin", "worker3.bin"};

    for (int i = 0; i < MAX_WORKERS; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            execl("./ln_pt2", "./ln_pt2", files[i], NULL);
            perror("execl failed");
            exit(1);
        } else if (pid > 0) {
            worker_pids[i] = pid;
        } else {
            perror("fork failed");
            exit(1);
        }
    }

    const int timeout_sec = 60;
    time_t start = time(NULL);

    while (completed_workers < MAX_WORKERS) {
        sleep(1);
        if (time(NULL) - start >= timeout_sec) {
            printf("Timeout reached. Exiting.\n");
            break;
        }
    }

    for (int i = 0; i < MAX_WORKERS; i++) {
        waitpid(worker_pids[i], NULL, 0);
    }

    return 0;
}
