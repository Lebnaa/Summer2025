// server.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>

#define SOCKET_PATH "/tmp/lab6"
#define BUFFER_SIZE 128

int main() {
    int server_fd, client_fd;
    struct sockaddr_un addr;
    char buffer[BUFFER_SIZE];

    unlink(SOCKET_PATH); // Remove old socket file

    if ((server_fd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
        perror("Server: socket");
        exit(1);
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path)-1);

    if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {
        perror("Server: bind");
        close(server_fd);
        exit(1);
    }

    if (listen(server_fd, 5) == -1) {
        perror("Server: listen");
        close(server_fd);
        exit(1);
    }

    printf("Server: waiting for client to connect...\n");

    if ((client_fd = accept(server_fd, NULL, NULL)) == -1) {
        perror("Server: accept");
        close(server_fd);
        exit(1);
    }

    printf("Server: client connected.\n");

    // Step 1: Send "Pid"
    strcpy(buffer, "Pid");
    write(client_fd, buffer, strlen(buffer));
    printf("Server: Sent command -> %s\n", buffer);

    // Step 2: Receive response
    memset(buffer, 0, BUFFER_SIZE);
    read(client_fd, buffer, BUFFER_SIZE);
    printf("Server: Received -> %s\n", buffer);

    // Step 3: Send "Sleep"
    strcpy(buffer, "Sleep");
    write(client_fd, buffer, strlen(buffer));
    printf("Server: Sent command -> %s\n", buffer);

    // Step 4: Wait for "Done"
    memset(buffer, 0, BUFFER_SIZE);
    read(client_fd, buffer, BUFFER_SIZE);
    printf("Server: Received -> %s\n", buffer);

    // Step 5: Send "Quit"
    strcpy(buffer, "Quit");
    write(client_fd, buffer, strlen(buffer));
    printf("Server: Sent command -> %s\n", buffer);

    close(client_fd);
    close(server_fd);
    unlink(SOCKET_PATH);
    printf("Server: closed and exiting.\n");

    return 0;
}
