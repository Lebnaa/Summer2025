// client.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <errno.h>

#define SOCKET_PATH "/tmp/lab6"
#define BUFFER_SIZE 128

int main() {
    int sock_fd;
    struct sockaddr_un addr;
    char buffer[BUFFER_SIZE];

    if ((sock_fd = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
        perror("Client: socket");
        exit(1);
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOCKET_PATH, sizeof(addr.sun_path)-1);

    if (connect(sock_fd, (struct sockaddr*)&addr, sizeof(addr)) == -1) {
        perror("Client: connect");
        close(sock_fd);
        exit(1);
    }

    printf("Client: connected to server.\n");

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        int bytes = read(sock_fd, buffer, BUFFER_SIZE);
        if (bytes <= 0) {
            perror("Client: read");
            break;
        }

        printf("Client: Received command -> %s\n", buffer);

        if (strcmp(buffer, "Pid") == 0) {
            snprintf(buffer, BUFFER_SIZE, "This client has pid %d", getpid());
            write(sock_fd, buffer, strlen(buffer));
        } else if (strcmp(buffer, "Sleep") == 0) {
            printf("Client: Sleeping for 5 seconds...\n");
            sleep(5);
            strcpy(buffer, "Done");
            write(sock_fd, buffer, strlen(buffer));
        } else if (strcmp(buffer, "Quit") == 0) {
            printf("Client: Received Quit. Exiting...\n");
            break;
        } else {
            printf("Client: Unknown command.\n");
        }
    }

    close(sock_fd);
    return 0;
}
