package lebna.week08.w3.controller;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import java.util.List;
import java.util.function.Consumer;
import lebna.week08.w3.model.Loan;

public class SavedRateController {

    private List<Loan> loans;
    private Consumer<Loan> onLoanSelected;

    @FXML
    private ListView<String> savedRatesListView;

    public void setSavedRates(ObservableList<String> savedRates, List<Loan> loans, Consumer<Loan> onLoanSelected) {
        this.loans = loans;
        this.onLoanSelected = onLoanSelected;
        savedRatesListView.setItems(savedRates);
    }

    @FXML
    public void handleDoubleClick(MouseEvent event) {
        if (event.getClickCount() == 2) {
            int selectedIndex = savedRatesListView.getSelectionModel().getSelectedIndex();
            if (selectedIndex >= 0 && selectedIndex < loans.size()) {
                onLoanSelected.accept(loans.get(selectedIndex));
            }
        }
    }

    @FXML
    public void handleClose() {
        closeWindow();
    }

    private void closeWindow() {
        savedRatesListView.getScene().getWindow().hide();
    }
}
