package lebna.week08.w3.model;

public class Login {
    private String userName;
    private String password;

    public Login(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean validate() {
        return (("user1".equals(userName) && "pass1".equals(password)) ||
                ("user2".equals(userName) && "pass2".equals(password)));
    }
}
