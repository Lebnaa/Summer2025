/**********************************************
 Workshop #
 Course:<subject type> - Semester
 Last Name:Noori
 First Name:Lebna
 ID:157672205
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:June-29
 **********************************************/

package lebna.week08.w3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("LoginView.fxml"));
        primaryStage.setTitle("Auto Loan Application");
        primaryStage.setScene(new Scene(root, 600, 400));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
