/**********************************************
 Workshop #
 Course:<subject type> - Semester
 Last Name:Noori
 First Name:Lebna
 ID:157672205
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:June-29
 **********************************************/


package lebna.week08.w3.controller;

import lebna.week08.w3.model.Loan;
import lebna.week08.w3.model.FixedRateLoan;
import lebna.week08.w3.model.Customer;
import lebna.week08.w3.model.Vehicle;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.collections.FXCollections;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AutoLoanController {
    private Loan currentLoan;
    private List<Loan> savedRates = new ArrayList<>();

    @FXML private TextField nameField, phoneField, cityField;
    @FXML private ComboBox<String> provinceComboBox;
    @FXML private RadioButton carRadio, truckRadio, vanRadio;
    @FXML private ToggleGroup vehicleTypeGroup;
    @FXML private RadioButton newRadio, usedRadio;
    @FXML private ToggleGroup vehicleAgeGroup;
    @FXML private TextField priceField, downPaymentField;
    @FXML private RadioButton rate099, rate199, rate299, rateOther;
    @FXML private ToggleGroup interestRateGroup;
    @FXML private TextField customRateField;
    @FXML private Slider durationSlider;
    @FXML private RadioButton weeklyRadio, biweeklyRadio, monthlyRadio;
    @FXML private ToggleGroup frequencyGroup;
    @FXML private Text monthlyPaymentText;

    @FXML
    public void initialize() {
        provinceComboBox.getItems().addAll(
                "AB", "BC", "MB", "NB", "NL", "NS", "NT", "NU", "ON", "PE", "QC", "SK", "YT"
        );
        provinceComboBox.getSelectionModel().selectFirst();

        vehicleTypeGroup.selectToggle(carRadio);
        vehicleAgeGroup.selectToggle(newRadio);
        interestRateGroup.selectToggle(rate099);
        customRateField.setDisable(true);
        durationSlider.setMin(12);
        durationSlider.setMax(96);
        durationSlider.setValue(60);
        frequencyGroup.selectToggle(monthlyRadio);
        monthlyPaymentText.setText("");
    }

    @FXML
    public void clearFields() {
        nameField.clear();
        phoneField.clear();
        cityField.clear();
        provinceComboBox.getSelectionModel().selectFirst();

        vehicleTypeGroup.selectToggle(carRadio);
        vehicleAgeGroup.selectToggle(newRadio);

        priceField.clear();
        downPaymentField.clear();

        interestRateGroup.selectToggle(rate099);
        customRateField.clear();
        customRateField.setDisable(true);

        durationSlider.setValue(60);

        frequencyGroup.selectToggle(monthlyRadio);

        monthlyPaymentText.setText("");
    }

    @FXML
    public void handleCalculate() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String city = cityField.getText().trim();
        String province = provinceComboBox.getValue();

        if (name.isEmpty() || phone.isEmpty() || city.isEmpty() || province == null) {
            showAlert("Input Error", "Please fill in all personal information fields.");
            return;
        }

        RadioButton selectedVehicleType = (RadioButton) vehicleTypeGroup.getSelectedToggle();
        RadioButton selectedVehicleAge = (RadioButton) vehicleAgeGroup.getSelectedToggle();

        if (selectedVehicleType == null || selectedVehicleAge == null) {
            showAlert("Input Error", "Please select vehicle type and age.");
            return;
        }

        double price;
        double downPayment;
        try {
            price = Double.parseDouble(priceField.getText().trim());
            downPayment = Double.parseDouble(downPaymentField.getText().trim());
            if (price <= 0 || downPayment < 0 || downPayment > price) {
                showAlert("Input Error", "Please enter valid price and down payment amounts.");
                return;
            }
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Price and down payment must be numeric.");
            return;
        }

        double interestRate;
        RadioButton selectedRate = (RadioButton) interestRateGroup.getSelectedToggle();
        if (selectedRate == rateOther) {
            try {
                interestRate = Double.parseDouble(customRateField.getText().trim());
                if (interestRate <= 0 || interestRate > 100) {
                    showAlert("Input Error", "Please enter a valid custom interest rate (0-100).");
                    return;
                }
            } catch (NumberFormatException e) {
                showAlert("Input Error", "Custom interest rate must be numeric.");
                return;
            }
        } else if (selectedRate == rate099) {
            interestRate = 0.99;
        } else if (selectedRate == rate199) {
            interestRate = 1.99;
        } else if (selectedRate == rate299) {
            interestRate = 2.99;
        } else {
            showAlert("Input Error", "Please select an interest rate.");
            return;
        }

        int duration = (int) durationSlider.getValue();

        RadioButton selectedFrequency = (RadioButton) frequencyGroup.getSelectedToggle();
        if (selectedFrequency == null) {
            showAlert("Input Error", "Please select a payment frequency.");
            return;
        }
        String frequency = selectedFrequency.getText();

        String vehicleType = selectedVehicleType.getText();
        String vehicleAge = selectedVehicleAge.getText();

        Customer customer = new Customer();
        customer.setName(name);
        customer.setPhone(phone);
        customer.setCity(city);
        customer.setProvince(province);

        Vehicle vehicle = new Vehicle();
        vehicle.setType(vehicleType);
        vehicle.setAge(vehicleAge);

        Loan baseLoan = new Loan(price, downPayment, interestRate, duration, frequency, customer, vehicle);
        FixedRateLoan loan = new FixedRateLoan(baseLoan);

        double payment = loan.calculateMonthlyPayment();

        monthlyPaymentText.setText(String.format("$%.2f", payment));
        currentLoan = baseLoan;
    }

    @FXML
    private void saveCurrentRate() {
        if (currentLoan != null) {
            savedRates.add(currentLoan);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Rate Saved");
            alert.setHeaderText(null);
            alert.setContentText("The current loan rate has been saved.");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Loan");
            alert.setHeaderText(null);
            alert.setContentText("No loan has been calculated to save.");
            alert.showAndWait();
        }
    }

    @FXML
    public void openSavedRatesView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/lebna/week08/w3/SavedRatesView.fxml"));
            Parent root = loader.load();

            // Prepare display strings for the ListView
            var displayList = FXCollections.observableArrayList(
                    savedRates.stream()
                            .map(loan -> String.format("%s: $%.2f @ %.2f%%",
                                    loan.getCustomer().getName(),
                                    loan.getAmount(),
                                    loan.getInterestRate()))
                            .toList()
            );

            // Pass the saved loans and a callback to load the selected loan
            lebna.week08.w3.controller.SavedRateController controller = loader.getController();
            controller.setSavedRates(displayList, savedRates, this::loadSelectedLoan);

            Stage stage = new Stage();
            stage.setTitle("Saved Rates");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to open Saved Rates view.");
            e.printStackTrace();
        }
    }

    @FXML
    public void openAmortizationView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/lebna/week08/w3/AmortizationView.fxml"));
            Parent root = loader.load();
            AmortizationController controller = loader.getController();
            // Pass the current loan (make sure currentLoan is not null)
            if (currentLoan == null) {
                showAlert("Error", "No loan calculated to display amortization.");
                return;
            }
            controller.setLoan(currentLoan);
            controller.generateSchedule();

            Stage stage = new Stage();
            stage.setTitle("Amortization Schedule");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showAlert("Error", "Failed to open Amortization view.");
            e.printStackTrace();
        }
    }

    public void loadSelectedLoan(Loan loan) {
        if (loan == null) return;

        Customer customer = loan.getCustomer();
        Vehicle vehicle = loan.getVehicle();

        nameField.setText(customer.getName());
        phoneField.setText(customer.getPhone());
        cityField.setText(customer.getCity());
        provinceComboBox.setValue(customer.getProvince());

        switch (vehicle.getType()) {
            case "Car": vehicleTypeGroup.selectToggle(carRadio); break;
            case "Truck": vehicleTypeGroup.selectToggle(truckRadio); break;
            case "Van": vehicleTypeGroup.selectToggle(vanRadio); break;
            default: vehicleTypeGroup.selectToggle(carRadio); break;
        }

        switch (vehicle.getAge()) {
            case "New": vehicleAgeGroup.selectToggle(newRadio); break;
            case "Used": vehicleAgeGroup.selectToggle(usedRadio); break;
            default: vehicleAgeGroup.selectToggle(newRadio); break;
        }

        priceField.setText(String.valueOf(loan.getAmount()));
        downPaymentField.setText(String.valueOf(loan.getDownPayment()));

        double rate = loan.getInterestRate();
        if (rate == 0.99) {
            interestRateGroup.selectToggle(rate099);
            customRateField.clear();
            customRateField.setDisable(true);
        } else if (rate == 1.99) {
            interestRateGroup.selectToggle(rate199);
            customRateField.clear();
            customRateField.setDisable(true);
        } else if (rate == 2.99) {
            interestRateGroup.selectToggle(rate299);
            customRateField.clear();
            customRateField.setDisable(true);
        } else {
            interestRateGroup.selectToggle(rateOther);
            customRateField.setDisable(false);
            customRateField.setText(String.valueOf(rate));
        }

        durationSlider.setValue(loan.getDuration());

        switch (loan.getFrequency()) {
            case "Weekly": frequencyGroup.selectToggle(weeklyRadio); break;
            case "Biweekly": frequencyGroup.selectToggle(biweeklyRadio); break;
            case "Monthly": frequencyGroup.selectToggle(monthlyRadio); break;
            default: frequencyGroup.selectToggle(monthlyRadio); break;
        }

        monthlyPaymentText.setText(String.format("$%.2f", loan.calculatePayment()));
        currentLoan = loan;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
