package lebna.week08.w3.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FixedRateLoan implements LoanCalculation {

    private Loan loan;

    public FixedRateLoan(Loan loan) {
        this.loan = loan;
    }

    @Override
    public double calculateMonthlyPayment() {
        double principal = loan.getAmount() - loan.getDownPayment();
        double monthlyRate = loan.getInterestRate() / 100 / 12;
        int numberOfPayments = loan.getDuration();

        if (monthlyRate == 0) {
            return principal / numberOfPayments;
        }

        return (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -numberOfPayments));
    }

    @Override
    public List<LoanAmortization> generateAmortizationSchedule() {
        List<LoanAmortization> schedule = new ArrayList<>();

        double principalRemaining = loan.getAmount() - loan.getDownPayment();
        double annualRate = loan.getInterestRate() / 100.0;

        // Determine payments per year
        int paymentsPerYear = switch (loan.getFrequency()) {
            case "Weekly" -> 52;
            case "Biweekly" -> 26;
            default -> 12;
        };

        int totalPayments = loan.getDuration(); // This should be in terms of *periods*, not months
        if (paymentsPerYear != 12) {
            // Convert duration in months to periods
            totalPayments = (loan.getDuration() * paymentsPerYear) / 12;
        }

        double periodicRate = annualRate / paymentsPerYear;

        double paymentAmount;
        if (periodicRate == 0) {
            paymentAmount = principalRemaining / totalPayments;
        } else {
            double factor = Math.pow(1 + periodicRate, totalPayments);
            paymentAmount = (principalRemaining * periodicRate * factor) / (factor - 1);
        }

        LocalDate paymentDate = LocalDate.now();

        for (int i = 1; i <= totalPayments; i++) {
            double interest = principalRemaining * periodicRate;
            double principal = paymentAmount - interest;
            principalRemaining -= principal;
            if (principalRemaining < 0) principalRemaining = 0;

            schedule.add(new LoanAmortization(
                    i,
                    paymentDate,
                    round(paymentAmount),
                    round(interest),
                    round(principal),
                    round(principalRemaining)
            ));

            if (paymentsPerYear == 52) {
                paymentDate = paymentDate.plusWeeks(1);
            } else if (paymentsPerYear == 26) {
                paymentDate = paymentDate.plusWeeks(2);
            } else {
                paymentDate = paymentDate.plusMonths(1);
            }
        }

        return schedule;
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
