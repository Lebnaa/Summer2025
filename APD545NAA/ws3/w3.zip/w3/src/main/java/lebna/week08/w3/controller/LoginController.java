/**********************************************
 Workshop #
 Course:<subject type> - Semester
 Last Name:Noori
 First Name:Lebna
 ID:157672205
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:June-29
 **********************************************/


package lebna.week08.w3.controller;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import lebna.week08.w3.model.Login;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    public void initialize() {
        // Optional setup logic
    }

    @FXML
    public void handleLogin() {

        String username = usernameField.getText();
        String password = passwordField.getText();

        Login login = new Login(username, password);
        if (login.validate()) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/lebna/week08/w3/AutoLoanView.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Auto Loan Application");
                stage.setScene(new Scene(root));
                stage.show();

                // Close current login window
                Stage currentStage = (Stage) usernameField.getScene().getWindow();
                currentStage.close();

            } catch (IOException e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Unable to load the application view.");
                alert.setContentText(e.getMessage());
                alert.showAndWait();
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText(null);
            alert.setContentText("Invalid username or password.");
            alert.showAndWait();

            usernameField.requestFocus();
        }
    }
}
