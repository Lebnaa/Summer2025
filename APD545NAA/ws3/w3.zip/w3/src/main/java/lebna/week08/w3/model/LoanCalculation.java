package lebna.week08.w3.model;
import java.util.List;

public interface LoanCalculation {
    double calculateMonthlyPayment();
    List<LoanAmortization> generateAmortizationSchedule();
}
