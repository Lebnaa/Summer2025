/**********************************************
 Workshop #
 Course:<subject type> - Semester
 Last Name:Noori
 First Name:Lebna
 ID:157672205
 This assignment represents my own work in accordance with Seneca Academic Policy.
 Signature
 Date:June-29
 **********************************************/

package lebna.week08.w3.controller;

import lebna.week08.w3.model.Loan;
import lebna.week08.w3.model.FixedRateLoan;
import lebna.week08.w3.model.LoanAmortization;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.time.LocalDate;  // <-- Add this import
import java.util.List;

public class AmortizationController {

    private Loan loan;

    @FXML
    private TableView<LoanAmortization> amortizationTable;

    @FXML
    private TableColumn<LoanAmortization, Integer> paymentNoColumn;
    @FXML
    private TableColumn<LoanAmortization, LocalDate> paymentDateColumn;
    @FXML
    private TableColumn<LoanAmortization, Double> paymentAmountColumn;
    @FXML
    private TableColumn<LoanAmortization, Double> interestPaymentColumn;
    @FXML
    private TableColumn<LoanAmortization, Double> principalPaymentColumn;
    @FXML
    private TableColumn<LoanAmortization, Double> remainingBalanceColumn;

    @FXML
    private void initialize() {
        paymentNoColumn.setCellValueFactory(new PropertyValueFactory<>("paymentNo"));
        paymentDateColumn.setCellValueFactory(new PropertyValueFactory<>("paymentDate"));
        paymentAmountColumn.setCellValueFactory(new PropertyValueFactory<>("paymentAmount"));
        interestPaymentColumn.setCellValueFactory(new PropertyValueFactory<>("interestPayment"));
        principalPaymentColumn.setCellValueFactory(new PropertyValueFactory<>("principalPayment"));
        remainingBalanceColumn.setCellValueFactory(new PropertyValueFactory<>("remainingBalance"));
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
        generateSchedule();
    }

    public void generateSchedule() {
        if (loan == null) return;

        FixedRateLoan fixedLoan = new FixedRateLoan(loan);
        List<LoanAmortization> schedule = fixedLoan.generateAmortizationSchedule();

        amortizationTable.setItems(FXCollections.observableArrayList(schedule));
    }

    @FXML
    private void handleClose() {
        Stage stage = (Stage) amortizationTable.getScene().getWindow();
        stage.close();
    }
}
